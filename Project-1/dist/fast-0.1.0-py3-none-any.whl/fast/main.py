# def my_first_fucntion():
#     return("Hello, World!")



# if __name__ == "__main__":
#     print(my_first_fucntion())
def function() ->str:
    return "Hello, World!"

results : str = function()

print(results)